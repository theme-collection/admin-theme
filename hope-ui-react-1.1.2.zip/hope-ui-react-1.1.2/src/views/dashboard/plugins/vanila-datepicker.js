import React from 'react'

const VanilaDatepicker = () => {
    return (
        <div>
            
        </div>
    )
}

export default VanilaDatepicker
