import React from 'react'

const HorizontalMulti2 = () => {
    return (
        <div>
            
        </div>
    )
}

export default HorizontalMulti2
