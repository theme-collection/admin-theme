import React from 'react'

const Colored = () => {
    return (
        <div>
            
        </div>
    )
}

export default Colored
