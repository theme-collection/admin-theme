
import React from 'react'

const RtlSupport = () => {
    return (
        <div>
            
        </div>
    )
}

export default RtlSupport
