

const UserAccountSetting =() =>{
  return(
      <div>UserAccountSetting</div>
  )

}

export default UserAccountSetting;