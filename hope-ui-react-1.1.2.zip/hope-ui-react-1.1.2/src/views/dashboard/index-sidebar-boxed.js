import React from 'react'

const SidebarBoxed = () => {
    return (
        <div>
            
        </div>
    )
}

export default SidebarBoxed
