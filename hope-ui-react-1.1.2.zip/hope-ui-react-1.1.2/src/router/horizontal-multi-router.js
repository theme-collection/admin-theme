import React from 'react'
import Index from '../views/dashboard/index'

const HorizontalMultiRouter = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default HorizontalMultiRouter
