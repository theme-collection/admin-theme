'use strict';
require('./gulp/index.js')