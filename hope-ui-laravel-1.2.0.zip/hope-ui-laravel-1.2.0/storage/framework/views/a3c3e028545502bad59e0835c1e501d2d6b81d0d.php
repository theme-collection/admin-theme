<div class="loader simple-loader">
    <div class="loader-body"></div>
</div>

<?php /**PATH /home/anurag/Documents/sites/hopeUI development/hope-ui/laravel/resources/views/partials/dashboard/_body_loader.blade.php ENDPATH**/ ?>