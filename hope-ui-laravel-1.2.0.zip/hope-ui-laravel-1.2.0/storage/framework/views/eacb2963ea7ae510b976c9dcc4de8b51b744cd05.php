<?php echo e(Form::open(['url' => '#','method' => 'post'])); ?>

    <div class="form-group">
        <label class="form-label">role title</label>
        <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','id' => 'role-title', 'placeholder' => 'Role Title', 'required'])); ?>

    </div>
    <label class="form-label">Status</label>
    <div class="form-check">
        <?php echo e(Form::radio('status', '1',old('status'), ['class' => 'form-check-input', 'id' => 'roleassigned'])); ?>

        <label class="form-check-label" for="roleassigned">yes</label>
    </div>
    <div class="mb-3 form-check">
        <?php echo e(Form::radio('status', '0',old('status'), ['class' => 'form-check-input', 'id' => 'rolenotassigned'])); ?>

        <label class="form-check-label" for="rolenotassigned">no</label>
    </div>
    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Save</button>
    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
<?php echo e(Form::close()); ?><?php /**PATH /home/anurag/Documents/hope UI/hope Ui free/hopeUI development/hope-ui/laravel/resources/views/role-permission/form-role.blade.php ENDPATH**/ ?>