<div class="loader simple-loader">
    <div class="loader-body"></div>
</div>

<?php /**PATH /home/anurag/Documents/hope UI/hope Ui free/hopeUI development/hope-ui/laravel/resources/views/partials/dashboard/_body_loader.blade.php ENDPATH**/ ?>