<?php echo e(Form::open(['url' => '#','method' => 'post'])); ?>

    <div class="form-group">
        <label class="form-label">permission title</label>
        <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','id' => 'permission-title', 'placeholder' => 'Permission Title', 'required'])); ?>

    </div>
    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Save</button>
    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
<?php echo e(Form::close()); ?><?php /**PATH /home/anurag/Documents/hope UI/hope Ui free/hopeUI development/hope-ui/laravel/resources/views/role-permission/form-permission.blade.php ENDPATH**/ ?>