<div id="loading">
    <?php echo $__env->make('partials.dashboard._body_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<main class="main-content">
<?php echo $__env->make('partials.dashboard._body_header4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="conatiner-fluid content-inner pb-0">
    <?php echo e($slot); ?>

    </div>
    <?php echo $__env->make('partials.dashboard._body_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main>
<?php echo $__env->make('partials.dashboard._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anurag/Documents/hope UI/hope Ui free/hopeUI development/hope-ui/laravel/resources/views/partials/dashboard/_body4.blade.php ENDPATH**/ ?>