

<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/libs.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/hope-ui.css?v=1.1.0')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css?v=1.1.0')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/dark.css?v=1.1.0')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/rtl.css?v=1.1.0')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/customizer.css?v=1.1.0')); ?>">

<!-- Fullcalender CSS -->
<link rel='stylesheet' href="<?php echo e(asset('vendor/fullcalendar/core/main.css')); ?>" />
<link rel='stylesheet' href="<?php echo e(asset('vendor/fullcalendar/daygrid/main.css')); ?>" />
<link rel='stylesheet' href="<?php echo e(asset('vendor/fullcalendar/timegrid/main.css')); ?>" />
<link rel='stylesheet' href="<?php echo e(asset('vendor/fullcalendar/list/main.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('vendor/Leaflet/leaflet.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('vendor/vanillajs-datepicker/dist/css/datepicker.min.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendor/aos/dist/aos.css')); ?>" />

<style>
    th.hide-search input{
       display: none;
    }
 </style>
<?php /**PATH /home/anurag/Documents/hope UI/hope Ui free/hopeUI development/hope-ui/laravel/resources/views/partials/dashboard/_head.blade.php ENDPATH**/ ?>